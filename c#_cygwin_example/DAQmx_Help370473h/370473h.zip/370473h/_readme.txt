To open the NI-DAQmx .NET Class Library Help for Visual Studio 2010, double-click the NIDAQmxDotNETHelpVS2010.chm file. 

If you cannot view the contents of the help file, refer to the KB document 4ZMAF4G0 on ni.com.